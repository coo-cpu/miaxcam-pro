import pandas as pd
import matplotlib.pyplot as plt
import io
import numpy as np
import os

# --- 步骤 1: 请在这里填写您的基本实验参数 ---
E = 1.5  # 电源电压 E (单位: V)
R0 = 5.1 # 电位器总电阻 R0 (单位: kΩ)

SAVE_FIG = True                 # 是否自动保存图片
SHOW_LIMIT_PLOT = True          # 是否显示“限流电路”图
SHOW_DIVIDER_PLOT = True      # 是否显示“分压电路”图（默认不显示）

# 保存目录与文件名（当前脚本所在目录）
OUTPUT_DIR = os.path.dirname(__file__)
LIMIT_FIG_PATH = os.path.join(OUTPUT_DIR, '限流电路_I_vs_K.png')
DIVIDER_FIG_PATH = os.path.join(OUTPUT_DIR, '分压电路特性曲线.png')



# --- 步骤 2: 将您在 Canvas 中记录的实验数据复制并粘贴到下面的三重引号内 ---
# 请确保格式与 Canvas 中的 CSV 文件完全一致，包括表头

# 表1：限流电路数据
limit_current_data_csv = """
负载电阻 RL (Ω),测量点 (从B到A),电位器电阻 RAC (kΩ),电流 I (mA)
300,1,5.1,0.27
300,2,4.5,0.31
300,3,4.0,0.34
300,4,3.5,0.39
300,5,3.0,0.45
300,6,2.5,0.53
300,7,2.0,0.65
300,8,1.5,0.83
300,9,1.0,1.15
300,10,0.5,1.87
500,1,5.1,0.26
500,2,4.5,0.30
500,3,4.0,0.33
500,4,3.5,0.37
500,5,3.0,0.42
500,6,2.5,0.50
500,7,2.0,0.60
500,8,1.5,0.75
500,9,1.0,1.0
500,10,0.5,1.5
1000,1,5.1,0.24
1000,2,4.5,0.27
1000,3,4.0,0.30
1000,4,3.5,0.33
1000,5,3.0,0.37
1000,6,2.5,0.42
1000,7,2.0,0.50
1000,8,1.5,0.60
1000,9,1.0,0.75
1000,10,0.5,1.0
"""

# 表2：分压电路数据
voltage_divider_data_csv = """
负载电阻 RL (Ω),测量点 (从A到B),电位器电阻 RAC (kΩ),负载电流I_L (A),负载电压 UL (V)
300,1,0.1,0.07,0.02
300,2,0.5,0.47,0.14
300,3,1.0,0.9,0.27
300,4,1.5,1.3,0.39
300,5,2.0,1.7,0.51
300,6,2.5,2.07,0.62
300,7,3.0,2.43,0.73
300,8,3.5,2.83,0.85
300,9,4.0,3.27,0.98
300,10,4.5,3.77,1.13
500,1,0.1,0.06,0.03
500,2,0.5,0.38,0.19
500,3,1.0,0.7,0.35
500,4,1.5,0.98,0.49
500,5,2.0,1.24,0.62
500,6,2.5,1.5,0.75
500,7,3.0,1.76,0.88
500,8,3.5,2.0,1.00
500,9,4.0,2.28,1.14
500,10,4.5,2.56,1.28
1000,1,0.1,0.03,0.03
1000,2,0.5,0.24,0.24
1000,3,1.0,0.44,0.44
1000,4,1.5,0.61,0.61
1000,5,2.0,0.75,0.75
1000,6,2.5,0.88,0.88
1000,7,3.0,1.0,1.00
1000,8,3.5,1.12,1.12
1000,9,4.0,1.23,1.23
1000,10,4.5,1.35,1.35
"""

# --- 脚本处理部分，您无需修改以下代码 ---

# 设置绘图样式，支持中文显示
plt.rcParams['font.sans-serif'] = ['SimHei', 'Heiti TC', 'sans-serif']
plt.rcParams['axes.unicode_minus'] = False

# --- 1. 分析限流电路 ---
try:
    df1 = pd.read_csv(io.StringIO(limit_current_data_csv))
    df1.columns = ['RL', 'Point', 'RAC', 'I']
    df1['K'] = df1['RAC'] / R0
    
    fig1 = plt.figure(figsize=(10, 6))
    
    # 绘制 I-K 关系图（K = RAC / R0）
    for rl_value in df1['RL'].unique():
        subset = df1[df1['RL'] == rl_value]
        # 将单位从 kΩ (RAC) 和 Ω (RL) 统一
        rl_numeric = float(str(rl_value).replace('k','')) * 1000 if 'k' in str(rl_value) else float(rl_value)
        rac_ohm = subset['RAC'] * 1000
        # 理论曲线
        i_theoretical = (E / (rac_ohm + rl_numeric)) * 1000 # 转换为mA
        plt.plot(subset['K'], i_theoretical, linestyle='--', color=plt.gca().lines[-1].get_color() if plt.gca().lines else None, alpha=0.7, label=f'理论值 RL={rl_value}Ω')
        plt.scatter(subset['K'], subset['I'], marker='o', label=f'测量值 RL={rl_value}Ω')
        
    plt.title('制流电路特性曲线 (I vs K)')
    plt.xlabel('电阻比 K = RAC/R0')
    plt.ylabel('电路电流 I (mA)')
    plt.grid(True)
    plt.legend()
    # 确保横轴从左到右递增
    try:
        plt.xlim(df1['K'].min(), df1['K'].max())
    except Exception:
        pass
    # 保存与显示控制
    if SAVE_FIG:
        fig1.savefig(LIMIT_FIG_PATH, dpi=300, bbox_inches='tight')
        print(f'已保存: {LIMIT_FIG_PATH}')
    if SHOW_LIMIT_PLOT:
        plt.show()
    else:
        plt.close(fig1)

except Exception as e:
    print(f"处理限流电路数据时出错: {e}")
    print("请检查您的限流电路CSV数据是否已正确粘贴。")


# --- 2. 分析分压电路 ---
try:
    df2 = pd.read_csv(io.StringIO(voltage_divider_data_csv))
    df2.columns = ['RL', 'Point', 'RAC', 'IL', 'UL']
    df2['K'] = df2['RAC'] / R0
    df2['Y'] = df2['UL'] / E

    fig2 = plt.figure(figsize=(12, 8))
    
    # 绘制 UL-RAC 关系图
    ax1 = plt.subplot(2, 1, 1)
    for rl_value in df2['RL'].unique():
        subset = df2[df2['RL'] == rl_value]
        ax1.plot(subset['RAC'], subset['UL'], marker='o', linestyle='-', label=f'RL={rl_value}Ω')
    
    ax1.set_title('分压电路特性曲线 (UL vs RAC)')
    ax1.set_xlabel('电位器电阻 RAC (kΩ)')
    ax1.set_ylabel('负载电压 UL (V)')
    ax1.grid(True)
    ax1.legend()
    
    # 绘制 Y-K 关系图
    ax2 = plt.subplot(2, 1, 2)
    for rl_value in df2['RL'].unique():
        subset = df2[df2['RL'] == rl_value]
        ax2.plot(subset['K'], subset['Y'], marker='x', linestyle='-', label=f'RL={rl_value}Ω')
        
    # 绘制理想分压曲线 (Y=K)
    ideal_k = np.linspace(0, 1, 100)
    ax2.plot(ideal_k, ideal_k, 'r--', label='理想情况 (RL -> ∞)')
    
    ax2.set_title('分压电路标准化特性曲线 (Y vs K)')
    ax2.set_xlabel('电阻比 K = RAC/R0')
    ax2.set_ylabel('分压比 Y = UL/E')
    ax2.grid(True)
    ax2.legend()
    
    plt.tight_layout()
    # 保存与显示控制（默认仅保存不显示）
    if SAVE_FIG:
        fig2.savefig(DIVIDER_FIG_PATH, dpi=300, bbox_inches='tight')
        print(f'已保存: {DIVIDER_FIG_PATH}')
    if SHOW_DIVIDER_PLOT:
        plt.show()
    else:
        plt.close(fig2)

except Exception as e:
    print(f"处理分压电路数据时出错: {e}")
    print("请检查您的分压电路CSV数据是否已正确粘贴。")
